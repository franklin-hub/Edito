<?php
/**
 * Plugin Spip 2.0 Reloaded
 * Ce que vous ne trouverez pas dans Spip 2.0
 * (c) 2008 Cedric Morin
 * Licence GPL
 * 
 */
if (!defined("_ECRIRE_INC_VERSION")) return;
$GLOBALS['spip_connect_version'] = 0.1;
spip_connect_db('host','port','login','pass','base','array', '','');
?>