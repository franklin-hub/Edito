<?php

// This is a SPIP language file  --  Ceci est un fichier langue de SPIP

$GLOBALS[$GLOBALS['idx_lang']] = array(

'afficher_calendrier' => 'Show the calendar',
'annee_precedente' => 'Previous year',
'annee_suivante' => 'Next year',
'annuler_recherche' => 'Cancel the search',

'bouton_fermer' => "Close",

'erreur_date' => 'This date is incorrect',
'erreur_date_corrigee' => 'The date has been corrected',
'erreur_heure' => 'This hour is incorrect',
'erreur_heure_corrigee' => 'The hour has been corrected',

'mois_precedent' => 'Previous month',
'mois_suivant' => 'Next month',
'id_rapide' => 'Ajout rapide',
'pages' => 'Pages',


);


?>