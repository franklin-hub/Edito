<?php

// This is a SPIP language file  --  Ceci est un fichier langue de SPIP

$GLOBALS[$GLOBALS['idx_lang']] = array(

'afficher_calendrier' => 'Afficher le calendrier',
'annee_precedente' => 'An&eacute;e pr&eacute;c&eacute;dente',
'annee_suivante' => 'Ann&eacute;e suivante',
'annuler_recherche' => 'Annuler la recherche',

'bouton_fermer' => "Fermer",

'erreur_date' => 'Cette date est incorrecte',
'erreur_date_corrigee' => 'La date a &eacute;t&eacute; corrig&eacute;e',
'erreur_heure' => 'Cette heure est incorrecte',
'erreur_heure_corrigee' => 'L\'heure a &eacute;t&eacute; corrig&eacute;e',

'mois_precedent' => 'Mois pr&eacute;c&eacute;dent',
'mois_suivant' => 'Mois suivant',
'id_rapide' => 'Ajout rapide',
'pages' => 'Pages',


);


?>