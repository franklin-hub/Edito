<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/zen-garden/lang
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Previsualizar',

	// B
	'bandeau_personalisable' => 'Personalizar la imagen de la cabecera para este tema',

	// C
	'choix_theme' => 'Seleccionar un tema',
	'choisir_ce_theme' => 'Seleccionar',

	// D
	'desactiver_ce_theme' => 'Desactivar el tema y volver al estilo inicial del sitio',

	// I
	'info_page' => 'Puedes seleccionar uno de los temas propuestos, o s&oacute;lo previsualizarlos sin modificar la visualizaci&oacute;n actual del sitio',
	'intitule_compatiblite_squelette' => 'S&oacute;lo es compatible con un esqueleto',
	'intitule_version' => 'versi&oacute;n',

	// M

	// P

	// R

	// S
	'switcher_activer' => 'Activar el switcher de temas en el sitio p&uacute;blico',
	'switcher_desactiver' => 'Desactivar el switcher de temas',

	// T
	'theme_actif' => 'Este tema se utiliza actualmente',
	'themes' => 'Temas',

	// V

	// Z
);

?>
