<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/zen-garden/lang
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Preview',

	// B
	'bandeau_personalisable' => 'You can customize the image in the banner of this theme',

	// C
	'choix_theme' => 'Choose your theme',
	'choisir_ce_theme' => 'Choose',

	// D
	'desactiver_ce_theme' => 'Deactivate and return to default style',

	// I
	'info_page' => 'You can choose one of the suggested theme or just see his rendering without changing the display to your visitors',
	'intitule_compatiblite_squelette' => 'Compatible only with the skeletons',
	'intitule_version' => 'version',

	// M

	// P

	// R

	// S
	'switcher_activer' => 'Activate the theme switcher on the public site',
	'switcher_desactiver' => 'Disable the themes switcher',

	// T
	'theme_actif' => 'This theme is currently used',
	'themes' => 'Themes',

	// V

	// Z
	
);

?>
