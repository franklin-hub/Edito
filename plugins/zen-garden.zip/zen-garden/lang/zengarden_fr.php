<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/zen-garden/lang
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'apercevoir_ce_theme' => 'Apercevoir',

	// B
	'bandeau_personalisable' => 'Vous pouvez personnaliser l\'image du bandeau de ce th&egrave;me',

	// C
	'choix_theme' => 'Choisissez votre th&egrave;me',
	'choisir_ce_theme' => 'Choisir',

	// D
	'desactiver_ce_theme' => 'D&eacute;sactiver et revenir au style par d&eacute;faut',

	// I
	'info_page' => 'Vous pouvez choisir un th&egrave;me propos&eacute; ou simplement apercevoir son rendu sans modifier l\'affichage pour vos visiteurs',
	'intitule_compatiblite_squelette' => 'Compatible uniquement avec les squelettes',
	'intitule_version' => 'version',

	// M

	// P

	// R

	// S
	'switcher_activer' => 'Activer le switcher de th&egrave;mes sur le site public',
	'switcher_desactiver' => 'Desactiver le switcher de th&egrave;mes',

	// T
	'theme_actif' => 'Ce th&egrave;me est actuellement utilis&eacute;',
	'themes' => 'Th&egrave;mes',

	// V

	// Z
	
);

?>
